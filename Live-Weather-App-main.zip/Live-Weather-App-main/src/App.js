import Page from "./components/Page/Page";

function App() {
  return (
    <div className="App">
      <Page />
    </div>
  );
}

export default App;
